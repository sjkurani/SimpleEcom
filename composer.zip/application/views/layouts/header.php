<!DOCTYPE html>
<?php 
    $this->benchmark->mark('code_start');
?>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>

  <meta content="utf-8" http-equiv="encoding">
  <title><?php echo $layout_title.' - '.$layout_description; ?></title>
  <?php echo $this->layouts->print_includes(); ?>
</head>
<body>
